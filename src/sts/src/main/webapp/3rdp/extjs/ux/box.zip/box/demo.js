// demo.js

Ext.onReady(function() {
	
	Ext.get('box-white').boxWrap().addClass('x-box-white');
	
	Ext.get('box').boxWrap();
	
	Ext.get('box-gray').boxWrap().addClass('x-box-gray');
	
	Ext.get('box-steelblue').boxWrap().addClass('x-box-steelblue');
	
});